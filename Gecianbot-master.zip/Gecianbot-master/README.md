# Gecianbot (Abstract)
The College bot project is built using machine learning algorithms that analyse user’s queries and understand the user's message. This System is a web application which provides answers to the query of the student. Students just have to query through the bot which is used for chatting. Students can chat using any format there is no specific format the user has to follow. The System uses built in machine learning to answer the query. The answers are appropriate to what the user queries. The User can query any college related activities through the system. The user does not have to personally go to the college for enquiry. The System analyses the question and then answers to the user. The system answers the query as if it is answered by the person. With the help of machine learning, the system answers the query asked by the students. The system replies using an effective Graphical user interface which implies that as if a real person is talking to the user.

# Images:  
![Alt Text](https://github.com/Kumavat-Vijay/Gecianbot/blob/master/Images_ss/Screenshot%20(199).png)
![Alt Text](https://github.com/Kumavat-Vijay/Gecianbot/blob/master/Images_ss/Register%20Form.png)
![Alt Text](https://github.com/Kumavat-Vijay/Gecianbot/blob/master/Images_ss/Login%20Form.png)
![Alt Text](https://github.com/Kumavat-Vijay/Gecianbot/blob/master/Images_ss/Google.reCaptcha.png)
![Alt Text](https://github.com/Kumavat-Vijay/Gecianbot/blob/master/Images_ss/Gecianbot.png)
![Alt Text](https://github.com/Kumavat-Vijay/Gecianbot/blob/master/Images_ss/Gecianbot%20(1).png)
![Alt Text](https://github.com/Kumavat-Vijay/Gecianbot/blob/master/Images_ss/Gecianbot%20(2).png)
